package com.provinzial.rubikscube;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RubikscubeApplicationTests {

	@Test
	void contextLoads() {
	}

}
