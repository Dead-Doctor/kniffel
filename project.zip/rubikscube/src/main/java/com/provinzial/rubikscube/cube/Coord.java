package com.provinzial.rubikscube.cube;

/**
 * @author XD98742
 */
public class Coord {
	private final int x;
	private final int y;
	private final int z;

	public Coord(int x, int y, int z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public Coord(Side... sides) {
		Coord sum = init(sides[0].axis, sides[0].positive);

		switch (sides.length) {
		case 3:
			if (sides[0].axis == sides[2].axis || sides[1].axis == sides[2].axis) { throw new IllegalStateException(); }
			sum = sum.add(init(sides[2].axis, sides[2].positive));

		case 2:
			if (sides[0].axis == sides[1].axis) { throw new IllegalStateException(); }
			sum = sum.add(init(sides[1].axis, sides[1].positive));

		case 1:
			break;

		default:
			throw new IllegalStateException();
		}

		x = sum.getX();
		y = sum.getY();
		z = sum.getZ();
	}

	private Coord init(int axis, boolean positive) {
		int x = 0, y = 0, z = 0;

		int value = positive ? 1 : -1;
		switch (axis) {
		case 0:
			x = value;
			break;
		case 1:
			y = value;
			break;
		case 2:
			z = value;
			break;
		default:
			throw new IllegalStateException();
		}

		return new Coord(x, y, z);
	}

	public Coord add(Coord other) {
		return new Coord(getX() + other.getX(), getY() + other.getY(), getZ() + other.getZ());
	}

	public int zeroAxes() {
		int result = 0;
		if (getX() == 0) { result++; }
		if (getY() == 0) { result++; }
		if (getZ() == 0) { result++; }
		return result;
	}

	public Coord rotateX() { return new Coord(getX(), -getZ(), getY()); }

	public Coord rotateY() { return new Coord(-getZ(), getY(), getX()); }

	public Coord rotateZ() { return new Coord(-getY(), getX(), getZ()); }

	public Coord rotate(int axis) {
		switch (axis) {
		case 0:
			return rotateX();
		case 1:
			return rotateY();
		case 2:
			return rotateZ();
		default:
			return null;
		}
	}

	public Side[] getSides() {
		Side[] result = new Side[3 - zeroAxes()];
		int i = 0;

		if (getX() != 0) { result[i++] = Side.get(0, getX() == 1); }
		if (getY() != 0) { result[i++] = Side.get(1, getY() == 1); }
		if (getZ() != 0) { result[i++] = Side.get(2, getZ() == 1); }

		return result;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + getX();
		result = prime * result + getY();
		result = prime * result + getZ();
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) { return true; }
		if (obj == null) { return false; }
		if (!(obj instanceof Coord)) { return false; }
		Coord other = (Coord) obj;
		return getX() == other.getX() && getY() == other.getY() && getZ() == other.getZ();
	}

	@Override
	public String toString() { return "X: " + x + ", Y: " + y + ", Z: " + z; }

	/**
	 * @return the x
	 */
	public int getX() { return x; }

	/**
	 * @return the y
	 */
	public int getY() { return y; }

	/**
	 * @return the z
	 */
	public int getZ() { return z; }

	/**
	 * @return
	 */
	public int getAxis() { // TODO Auto-generated method stub
		return getSides()[0].axis;
	}
}
