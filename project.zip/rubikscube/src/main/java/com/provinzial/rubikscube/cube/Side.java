package com.provinzial.rubikscube.cube;

/**
 * @author XD98742
 */
public enum Side {
	DOWN(1, false), FRONT(2, false), RIGHT(0, true), UP(1, true), BACK(2, true), LEFT(0, false);

	int axis;

	boolean positive;

	private Side(int axis, boolean positive) {
		this.axis = axis;
		this.positive = positive;
	}

	/**
	 * @param axis
	 * @param positive
	 * @return side
	 */
	public static Side get(int axis, boolean positive) {
		return values()[((positive ? 2 : -1) + axis + values().length) % values().length];
	}
}