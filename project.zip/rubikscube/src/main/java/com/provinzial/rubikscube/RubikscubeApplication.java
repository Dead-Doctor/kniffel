package com.provinzial.rubikscube;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RubikscubeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RubikscubeApplication.class, args);
	}

}
