package com.provinzial.rubikscube.cube;

/**
 * @author XD98742
 */
public enum Color {
	WHITE, GREEN, ORANGE, YELLOW, BLUE, RED;

	private Side side;

	private Color() { this.side = Side.values()[ordinal()]; }

	public Color getRight() { return values()[(ordinal() + 2) / 2 * 2 % 6]; }

	public Color getUp() { return values()[((ordinal() + 1) / 2 * 2 + 1) % 6]; }

	public Color getLeft() { return values()[(ordinal() / 2 * 2 + 5) % 6]; }

	public Color getDown() { return values()[((ordinal() + 5) / 2 * 2) % 6]; }

	public Color getBack() { return values()[(ordinal() + 2) % 6]; }

	public Side getSide() { return side; }
}
