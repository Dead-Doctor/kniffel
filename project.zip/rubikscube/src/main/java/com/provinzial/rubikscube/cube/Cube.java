package com.provinzial.rubikscube.cube;

import static com.provinzial.rubikscube.cube.Side.BACK;
import static com.provinzial.rubikscube.cube.Side.DOWN;
import static com.provinzial.rubikscube.cube.Side.FRONT;
import static com.provinzial.rubikscube.cube.Side.LEFT;
import static com.provinzial.rubikscube.cube.Side.RIGHT;
import static com.provinzial.rubikscube.cube.Side.UP;

import org.springframework.stereotype.Service;

/**
 * @author XD98742
 */
@Service
public class Cube {
	public int side = 0;
	public int rotation = 0;

	private Color[][][] faces = new Color[Side.values().length][3][3];

	public Cube() {
		for (Color color : Color.values()) {
			for (int y = 0; y < 3; y++) { for (int x = 0; x < 3; x++) { faces[color.ordinal()][y][x] = color; } }
		}
	}

	public Color map(Side offsetSide) {
		Color front = Color.values()[side];
		if (offsetSide == FRONT) { return front; }
		if (offsetSide == BACK) { return front.getBack(); }
		int offsetDirection = rotation;
		switch (offsetSide) {
		case LEFT:
			offsetDirection++;
		case DOWN:
			offsetDirection++;
		case RIGHT:
			offsetDirection++;
		}
		offsetDirection %= 4;
		switch (offsetDirection) {
		case 0:
			return front.getUp();
		case 1:
			return front.getRight();
		case 2:
			return front.getDown();
		case 3:
			return front.getLeft();
		}
		return null;
	}

	public Color[] getFace() {
		Color front = map(FRONT);
		int frontIndex = front.ordinal();
		Color[] result = new Color[9];
		for (int y = -1; y <= 1; y++) {
			for (int x = -1; x <= 1; x++) {
				Coord coord = new Coord(x, y, 0);
				for (int i = 0; i < rotation; i++) { coord = coord.rotateZ(); }
				result[(y + 1) * 3 + (x + 1)] = faces[frontIndex][coord.getY() + 1][coord.getX() + 1];
			}
		}
		return result;
	}

	public String getButton(int direction) {
		int nextSide = 0;
		switch (direction) {
		case 0:
			nextSide = map(UP).ordinal();
			break;
		case 1:
			nextSide = map(RIGHT).ordinal();
			break;
		case 2:
			nextSide = map(DOWN).ordinal();
			break;
		case 3:
			nextSide = map(LEFT).ordinal();
			break;
		}
		int nextRotation = rotation;
		if ((side % 2 == 0 && nextSide % 2 == 0) != ((side + 4 == nextSide) || (side - 2 == nextSide))) {
			nextRotation += 3;
		}
		if ((side % 2 == 1 && nextSide % 2 == 1) != ((side + 4 == nextSide) || (side - 2 == nextSide))) {
			nextRotation++;
		}
		return "/" + nextSide + "/" + nextRotation % 4;
	}

	private Side sideFromBtnId(int btn) {
		switch (btn) {
		case 0:
		case 5:
			return map(LEFT).getSide();
		case 1:
		case 4:
			return map(RIGHT).getSide();
		case 2:
		case 7:
			return map(UP).getSide();
		case 3:
		case 6:
			return map(DOWN).getSide();
		}
		return null;
	}

	public String getTurn(int btn) { return "~/turn?side=" + sideFromBtnId(btn) + "&dir=" + (btn % 2 == 0); }

	/**
	 * @param layer
	 * @param direction
	 */
	public void turn(Side side, boolean dir) {
		swapSides(side, dir);
		swapFace(side, dir);
	}

	private void swapSides(Side side, boolean direction) {
		int faceTurning = side.ordinal(); // YELLOW, UP
		Color colorTurning = Color.values()[faceTurning]; // YELLOW, UP

		Color[] neighbor = { colorTurning.getUp(), colorTurning.getRight(), colorTurning.getDown(),
				colorTurning.getLeft() };

		int[][][] positions = new int[4][3][2];
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 3; j++) {
				if (neighbor[i].getUp() == colorTurning) {
					positions[i][j][0] = j;
					positions[i][j][1] = 0;
				} else if (neighbor[i].getRight() == colorTurning) {
					positions[i][j][0] = 2;
					positions[i][j][1] = j;
				} else if (neighbor[i].getDown() == colorTurning) {
					positions[i][j][0] = 2 - j;
					positions[i][j][1] = 2;
				} else if (neighbor[i].getLeft() == colorTurning) {
					positions[i][j][0] = 0;
					positions[i][j][1] = 2 - j;
				}
			}
		}

		Color[][] facesInOrder = new Color[4][3];
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 3; j++) {
				facesInOrder[i][j] = faces[neighbor[i].ordinal()][positions[i][j][1]][positions[i][j][0]];
			}
		}

		int offset = direction ? 1 : 3;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 3; j++) {
				faces[neighbor[i].ordinal()][positions[i][j][1]][positions[i][j][0]] = facesInOrder[(i + offset)
						% 4][j];
			}
		}
	}

	private void swapFace(Side side, boolean direction) {
		Color[][] face = faces[side.ordinal()];

		int offset = direction ? 1 : 3;
		Color[] edges__ = { face[0][1], face[1][2], face[2][1], face[1][0] };
		Color[] corners = { face[0][0], face[0][2], face[2][2], face[2][0] };

		face[0] = new Color[] { corners[(0 + offset) % 4], edges__[(0 + offset) % 4], corners[(1 + offset) % 4] };
		face[1] = new Color[] { edges__[(3 + offset) % 4], face[1][1], edges__[(1 + offset) % 4] };
		face[2] = new Color[] { corners[(3 + offset) % 4], edges__[(2 + offset) % 4], corners[(2 + offset) % 4] };
	}
}
