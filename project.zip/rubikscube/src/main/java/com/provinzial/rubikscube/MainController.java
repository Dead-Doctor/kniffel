package com.provinzial.rubikscube;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.provinzial.rubikscube.cube.Cube;
import com.provinzial.rubikscube.cube.Side;

/**
 * @author XD98742
 */
@Controller
public class MainController {

	@Autowired
	Cube cube;

	@GetMapping
	public RedirectView index(RedirectAttributes attributes) {
		cube = new Cube();
		return new RedirectView("/" + cube.side + "/" + cube.rotation);
	}

	@GetMapping("/turn")
	public RedirectView turn(RedirectAttributes attributes, @RequestParam Side side, @RequestParam boolean dir) {
		cube.turn(side, dir);
		return new RedirectView("/" + cube.side + "/" + cube.rotation);
	}

	@GetMapping(value = "/{side}/{rotation}")
	public String view(Model model, @PathVariable int side, @PathVariable int rotation) {
		cube.side = side % 6;
		cube.rotation = rotation % 4;
		model.addAttribute("cube", cube);
		return "index";
	}
}
