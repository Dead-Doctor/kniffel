package kniffel.home;

import kniffel.Main;
import kniffel.dom.Button;
import kniffel.dom.MouseButton;

/**
 * @author XD98742
 */
public class PlayerCountSelectButton extends Button {

    public PlayerCountSelectButton() {
        show("Select", true, true);
    }

    @Override
    protected boolean onClick(int xPos, int yPos, MouseButton button) {
        Main.startGame(PlayerSelection.playerCount);
        return true;
    }
}
