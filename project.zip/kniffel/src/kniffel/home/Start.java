package kniffel.home;

import java.awt.Color;
import java.awt.Graphics;
import kniffel.dom.Window;

/**
 * @author XD98742
 */
public class Start extends Window {

    StartButton startButton;

    public Start() {
        startButton = add(new StartButton());
        show("Kniffel", 400, 250, 200, 100, Color.GRAY);
    }

    @Override
    protected void onDraw(Graphics g) {
        int buttonHeight = 30;
        int paddingSides = 50;
        startButton.offset(paddingSides, height() / 2 - buttonHeight / 2);
        startButton.size(width() - paddingSides * 2, buttonHeight);
    }

    @Override
    public void close() {
        if (StartButton.playerSelection != null) {
            StartButton.playerSelection.close();
        }
        super.close();
    }
}
