package kniffel.home;

import static kniffel.Constants.BACKGROUND_COLOR;
import static kniffel.Constants.DARK_BACKGROUND_COLOR;
import static kniffel.Constants.HOVER_COLOR;
import static kniffel.Constants.PADDING;
import java.awt.Graphics;
import kniffel.dom.MouseButton;
import kniffel.dom.Window;

/**
 * @author XD98742
 */
public class PlayerSelection extends Window {

    static int playerCount = 1;

    int numberPadding = 7;

    int numberWidth;

    PlayerCountSelectButton selectButton;

    public PlayerSelection() {
        selectButton = add(new PlayerCountSelectButton());
        show("Select Player Amount", 500, 50, -1, -1, BACKGROUND_COLOR);
    }

    @Override
    protected void onDraw(Graphics g) {
        numberWidth = (width() - numberPadding) / 9;

        for (int i = 0; i < 9; i++) {
            g.setColor(DARK_BACKGROUND_COLOR);
            g.drawString(String.valueOf(i + 1), numberWidth * i + numberPadding + numberWidth / 2 - 4, numberPadding + 13);
            if (i + 1 == playerCount) {
                g.setColor(HOVER_COLOR);
                g.drawRect((int) (numberWidth * (i + 0.5)) + numberPadding - 9, numberPadding, 16, 16);
            }
        }

        selectButton.offset(PADDING, numberPadding + 20 + PADDING);
        selectButton.size(width() - PADDING * 2, 23);
    }

    @Override
    protected boolean onClose() {
        StartButton.playerSelection = null;
        return true;
    }

    @Override
    protected boolean onClick(int xPos, int yPos, MouseButton button) {
        int selection = (xPos - numberPadding) / numberWidth;
        if (0 <= selection && selection <= 8) {
            playerCount = selection + 1;
        }
        update();
        return true;
    }
}
