package kniffel.home;

import kniffel.dom.Button;
import kniffel.dom.MouseButton;

/**
 * @author XD98742
 */
public class StartButton extends Button {

    public static PlayerSelection playerSelection;

    public StartButton() {
        show("START", true, true);
    }

    @Override
    protected boolean onClick(int xPos, int yPos, MouseButton button) {
        if (playerSelection == null || playerSelection.isClosed()) {
            playerSelection = new PlayerSelection();
            update();
            return true;
        }
        return false;
    }
}
