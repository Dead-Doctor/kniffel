package kniffel;

import kniffel.game.Player;
import kniffel.home.Start;

/**
 * @author XD98742
 */
public class Main {

    static Start start;

    public static void main(String[] args) {
        showStart();
    }

    public static void showStart() {
        start = new Start();
        if (Player.ui != null) {
            Player.ui.close();
        }
    }

    /**
     * @param playerCount
     */
    public static void startGame(int playerCount) {
        start.close();
        Player.reset(playerCount);
    }
}
