package kniffel;

import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * @author XD98742
 */
public class Constants {
    public static final int SCR_WIDTH = 500;

    public static final int SCR_MIN_WIDTH = 300;

    public static final int SCR_HEIGHT = 700;

    public static final int SCR_MIN_HEIGHT = 500;

    public static final int PADDING = 5;

    public static final float DICE_SECTION_HEIGHT = 0.3f;

    public static final Color BACKGROUND_COLOR = new Color(150, 150, 150);

    public static final Color FOREGROUND_COLOR = new Color(200, 200, 200);

    public static final Color DARK_BACKGROUND_COLOR = new Color(100, 100, 100);

    public static final Color HOVER_COLOR = new Color(97, 224, 0);

    public static final int DICE_DOT_SIZE = 10;

    public static final Color DICE_DOT_COLOR = DARK_BACKGROUND_COLOR;

    // @formatter:off
    public static final int[][][] DICE_FACES = new int[][][] {
        new int[][] { new int[] {  0,  0 }                                                                                                        },
        new int[][] { new int[] { -1, -1 }, new int[] { 1,  1 }                                                                                   },
        new int[][] { new int[] { -1, -1 }, new int[] { 0,  0 }, new int[] { 1, 1 }                                                               },
        new int[][] { new int[] { -1, -1 }, new int[] { 1, -1 }, new int[] { 1, 1 }, new int[] { -1, 1 }                                          },
        new int[][] { new int[] { -1, -1 }, new int[] { 1, -1 }, new int[] { 1, 1 }, new int[] { -1, 1 }, new int[] {  0, 0 }                     },
        new int[][] { new int[] { -1, -1 }, new int[] { 1, -1 }, new int[] { 1, 1 }, new int[] { -1, 1 }, new int[] { -1, 0 }, new int[] { 1, 0 } }
    };
    // @formatter:on

    private static Image lockedSymbol = null;

    static {
        try {
            lockedSymbol = ImageIO.read(new File("resources/lock_symbol.png"));
        } catch (IOException e) {
            System.out.println("Error loading Image: " + e.getLocalizedMessage());
        }
    }

    /**
     * @return the lOCKED_SYMBOL
     */
    public static Image getLockedSymbol() {
        return lockedSymbol;
    }

    private Constants() {
    }
}
