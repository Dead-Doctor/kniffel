package kniffel.dom;

import static kniffel.Constants.BACKGROUND_COLOR;
import static kniffel.Constants.DARK_BACKGROUND_COLOR;
import static kniffel.Constants.HOVER_COLOR;
import java.awt.Graphics;

/**
 * @author XD98742
 */
public class Table<T extends Enum<T> & TableEntries> extends Element {

    private T[] entries;

    float entryHeight;

    public Table(Class<T> enumClass) {
        entries = enumClass.getEnumConstants();
        entryHeight = (float) height() / entries.length;
        setUpdateOnMouseMove(true);
    }

    @Override
    protected void onDraw(Graphics g) {
        entryHeight = (float) height() / entries.length;

        g.setColor(DARK_BACKGROUND_COLOR);
        g.fillRect(0, 0, width() - 1, height());

        for (int i = 0; i < entries.length; i++) {
            float yOffset = entryHeight * i;

            String key = entries[i].getKey();
            String value = entries[i].getValue();

            if (entries[i].isHighlighted()) {
                g.setColor(BACKGROUND_COLOR);
                g.fillRect(0, (int) yOffset, width(), (int) entryHeight);
            }

            g.setColor(entries[i].getColor());
            g.drawRect(0, (int) yOffset, width() / 2, (int) entryHeight);
            g.drawRect(width() / 2, (int) yOffset, width() / 2 - 1, (int) entryHeight);

            if (entries[i].active() && isHovered() && (int) (mouseY() / entryHeight) == i) {
                g.setColor(HOVER_COLOR);
            }
            g.drawString(key, 10, (int) (yOffset + (entryHeight - 8) / 2) + 8);
            g.drawString(value, width() / 2 + 10, (int) (yOffset + (entryHeight - 8) / 2) + 8);
        }

        if (isHovered()) {
            int i = (int) (mouseY() / entryHeight);

            if (entries[i].active()) {
                float yOffset = entryHeight * i;
                g.setColor(HOVER_COLOR);
                g.drawRect(0, (int) yOffset, width() / 2, (int) entryHeight);
                g.drawRect(width() / 2, (int) yOffset, width() / 2 - 1, (int) entryHeight);
            }
        }
    }

    @Override
    protected boolean onClick(int xPos, int yPos, MouseButton button) {
        int i = (int) (yPos / entryHeight);
        if (entries[i].active()) {
            return entries[i].click(xPos, yPos - (int) (entryHeight * i), button, super::update);
        }
        return false;
    }

}
