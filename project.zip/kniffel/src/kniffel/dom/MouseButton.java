package kniffel.dom;

/**
 * @author XD98742
 */
public enum MouseButton {
    UNKNOWN, LEFT, MIDDLE, RIGHT, BACK, FRONT
}
