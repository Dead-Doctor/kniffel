package kniffel.dom;

import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Iterator;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author XD98742
 */
public abstract class Window extends Element implements WindowListener {

    public static boolean DEBUG = false;

    private JFrame frame;

    private Content content;

    private int width;

    private int height;

    private int minWidth;

    private int minHeight;

    private Color background;

    private boolean closed = true;

    public void show(String title, int width, int height, int minWidth, int minHeight, Color background) {
        this.width = width;
        this.height = height;
        this.minWidth = minWidth;
        this.minHeight = minHeight;
        this.background = background;
        this.closed = true;
        boolean resizeable = minWidth != -1 || minHeight != -1;

        size(width, height);
        frame = new JFrame();
        content = new Content();

        frame.add(content);
        frame.setTitle(title);
        frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        frame.setResizable(resizeable);
        if (resizeable) {
            frame.setMinimumSize(new Dimension(minWidth, minHeight));
        }
        frame.addWindowListener(this);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    @Override
    public void update() {
        if (content != null) {
            content.repaint();
        }
    }

    @Override
    public void windowClosing(WindowEvent e) {
        if (onClose()) {
            close();
        }
    }

    protected boolean onClose() {
        return true;
    }

    public void close() {
        closed = true;
        frame.setVisible(false);
        frame.dispose();
    }

    /**
     * @return the closed
     */
    public boolean isClosed() {
        return closed;
    }

    void printTree() {
        System.out.println(getClass().getSimpleName());

        for (Iterator<Element> iterator = children.iterator(); iterator.hasNext();) {
            Element c = iterator.next();
            c.printTree("", iterator.hasNext());
        }
    }

    /**
     * @param title
     */
    public void setTitle(String title) {
        if (frame != null) {
            frame.setTitle(title);
        }
    }

    private class Content extends JPanel implements ComponentListener, KeyListener, MouseListener, MouseMotionListener {
        private static final long serialVersionUID = 4328991165912716692L;

        public Content() {
            setPreferredSize(new Dimension(width, height));
            setMinimumSize(new Dimension(minWidth, minHeight));
            setBackground(Window.this.background);
            setFocusable(true);
            setFocusTraversalKeysEnabled(false);
            addKeyListener(this);
            addComponentListener(this);
            addMouseListener(this);
            addMouseMotionListener(this);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Window.this.draw(g);
        }

        @Override
        public void componentResized(ComponentEvent e) {
            // @formatter:off
            Window.this.size(
                (int) e.getComponent().getSize().getWidth(),
                (int) e.getComponent().getSize().getHeight()
            );
            // @formatter:on
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            Window.this.click(e.getX(), e.getY(), MouseButton.values()[e.getButton()]);
        }

        @Override
        public void mouseMoved(MouseEvent e) {
            Window.this.hover(e.getX(), e.getY(), true);
        }

        @Override
        public void keyTyped(KeyEvent e) {
            if (e.getKeyChar() == 'd') {
                DEBUG = !DEBUG;
                Window.this.update();
            } else if (e.getKeyChar() == 't') {
                Window.this.printTree();
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {
            // ignored
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            // ignored
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            // ignored

        }

        @Override
        public void mouseExited(MouseEvent e) {
            // ignored

        }

        @Override
        public void keyPressed(KeyEvent e) {
            // ignored
        }

        @Override
        public void keyReleased(KeyEvent e) {
            // ignored
        }

        @Override
        public void componentMoved(ComponentEvent e) {
            // ignored
        }

        @Override
        public void componentShown(ComponentEvent e) {
            // ignored
        }

        @Override
        public void componentHidden(ComponentEvent e) {
            // ignored
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            // ignored
        }
    }

    @Override
    public void windowClosed(WindowEvent e) {
        // ignored
    }

    @Override
    public void windowOpened(WindowEvent e) {
        // ignored

    }

    @Override
    public void windowIconified(WindowEvent e) {
        // ignored

    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        // ignored

    }

    @Override
    public void windowActivated(WindowEvent e) {
        // ignored

    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        // ignored

    }
}
