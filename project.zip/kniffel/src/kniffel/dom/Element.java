package kniffel.dom;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author XD98742
 */
public abstract class Element {
    private int x;

    private int y;

    private int w;

    private int h;

    private boolean hovered = false;

    private int mouseX;

    private int mouseY;

    private boolean updateOnMouseMove = false;

    private Element parent;

    protected List<Element> children = new ArrayList<>();

    boolean click(int xPos, int yPos, MouseButton button) {
        for (Element c : children) {
            if (c.x <= xPos && xPos < c.x + c.w && c.y <= yPos && yPos < c.y + c.h && c.click(xPos, yPos, button)) {
                return true;
            }
        }
        if (Window.DEBUG) {
            System.out.println(this.getClass()
                                   .getSimpleName()
                    + " => X: " + x + ", Y: " + y + ", Button: " + button);
        }
        return onClick(xPos - x, yPos - y, button);
    }

    void hover(int xPos, int yPos, boolean state) {
        mouseX = xPos;
        mouseY = yPos;
        boolean oldHovered = hovered;
        hovered = state;
        for (Element c : children) {
            if (!state) {
                c.hover(xPos, yPos, false);
            } else {
                boolean isHoveringChild = c.x <= xPos && xPos < c.x + c.w && c.y <= yPos && yPos < c.y + c.h;
                c.hover(xPos, yPos, isHoveringChild);
                if (isHoveringChild) {
                    hovered = false;
                }
            }
        }
        if (oldHovered != hovered || updateOnMouseMove) {
            update();
        }
    }

    void draw(Graphics g) {
        onDraw(g);
        if (Window.DEBUG) {
            if (hovered) {
                g.setColor(Color.YELLOW);
            } else {
                g.setColor(Color.RED);
            }
            g.drawRect(0, 0, width() - 1, height() - 1);
            g.setColor(Color.GREEN);
            g.fillRect(0, 0, 5, 5);
        }

        for (Element c : children) {
            int xDiff = c.x - x;
            int yDiff = c.y - y;

            g.translate(xDiff, yDiff);
            c.draw(g);
            g.translate(-xDiff, -yDiff);
        }
    }

    protected Element setParent(Element parent) {
        if (this.parent == null) {
            this.parent = parent;
        }
        return this;
    }

    public <T extends Element> T add(T e) {
        children.add(e.setParent(this));
        update();
        return e;
    }

    public <T extends Element> T remove(T e) {
        children.remove(e.setParent(null));
        return e;
    }

    protected void update() {
        if (parent == null) {
            onUpdate();
        } else {
            parent.update();
        }
    }

    void printTree(String prefix, boolean hasNext) {
        System.out.print(prefix);
        if (hasNext) {
            System.out.print("├");
        } else {
            System.out.print("└");
        }
        System.out.println("───" + getClass().getSimpleName());

        String trenner = "   ";
        String newPrefix;

        if (hasNext) {
            newPrefix = prefix + "│" + trenner;
        } else {
            newPrefix = prefix + " " + trenner;
        }

        for (Iterator<Element> iterator = children.iterator(); iterator.hasNext();) {
            Element c = iterator.next();
            c.printTree(newPrefix, iterator.hasNext());
        }
    }

    /*
     * Return if the click event should be consumed.
     */
    protected boolean onClick(int xPos, int yPos, MouseButton button) {
        return false;
    }

    protected abstract void onDraw(Graphics g);

    protected void onUpdate() {
    }

    public void offset(int x, int y) {
        if (parent == null) {
            this.x = x;
            this.y = y;
        } else {
            this.x = x + parent.x;
            this.y = y + parent.y;
        }
    }

    public void size(int w, int h) {
        this.w = w;
        this.h = h;
    }

    public void size(int s) {
        size(s, s);
    }

    /**
     * @return the width
     */
    public int width() {
        return w;
    }

    /**
     * @return the height
     */
    public int height() {
        return h;
    }

    public boolean isHovered() {
        return hovered;
    }

    /**
     * @return the mouseX
     */
    public int mouseX() {
        return mouseX - x;
    }

    /**
     * @return the mouseY
     */
    public int mouseY() {
        return mouseY - y;
    }

    /**
     * @return the updateOnMouseMove
     */
    public boolean isUpdateOnMouseMove() {
        return updateOnMouseMove;
    }

    /**
     * @param updateOnMouseMove the updateOnMouseMove to set
     */
    public void setUpdateOnMouseMove(boolean updateOnMouseMove) {
        this.updateOnMouseMove = updateOnMouseMove;
    }
}
