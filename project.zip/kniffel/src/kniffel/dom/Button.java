package kniffel.dom;

import static kniffel.Constants.DARK_BACKGROUND_COLOR;
import static kniffel.Constants.FOREGROUND_COLOR;
import static kniffel.Constants.HOVER_COLOR;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

/**
 * @author XD98742
 */
public class Button extends Element {

    private String text;

    private boolean active;

    private boolean centered;

    public void show(String text, boolean active, boolean centered) {
        this.text = text;
        this.active = active;
        this.centered = centered;
    }

    protected void beforeDraw(Graphics g) {
        // overidable
    }

    @Override
    protected void onDraw(Graphics g) {
        beforeDraw(g);

        g.setColor(DARK_BACKGROUND_COLOR);
        g.fillRect(0, 0, width() - 1, height() - 1);

        if (isHovered() && active) {
            g.setColor(HOVER_COLOR);
        } else {
            g.setColor(FOREGROUND_COLOR);
        }

        int textX = 10;
        if (centered) {
            Font f = g.getFont();
            FontMetrics fm = g.getFontMetrics(f);
            textX = width() / 2 - fm.stringWidth(text) / 2;
        }

        g.drawString(text, textX, height() / 2 + 4);
        g.drawRect(0, 0, width() - 1, height() - 1);

        afterDraw(g);
    }

    protected void afterDraw(Graphics g) {
        // overidable
    }

    /**
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * @param active the active to set
     */
    public void setActive(boolean active) {
        this.active = active;
    }
}
