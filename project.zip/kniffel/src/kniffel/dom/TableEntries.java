package kniffel.dom;

import java.awt.Color;

/**
 * @author XD98742
 */
public interface TableEntries {
    public String getKey();

    public String getValue();

    public boolean isHighlighted();

    public Color getColor();

    public boolean active();

    public boolean click(int xPos, int yPos, MouseButton button, Update update);

    interface Update {
        void update();
    }
}
