package kniffel.game;

import static kniffel.Constants.FOREGROUND_COLOR;
import static kniffel.game.Field.TOTAL;
import java.awt.Color;
import kniffel.dom.MouseButton;
import kniffel.dom.TableEntries;

/**
 * @author XD98742
 */
public enum PlayerScoreTable implements TableEntries {
    PLAYER1, PLAYER2, PLAYER3, PLAYER4, PLAYER5, PLAYER6, PLAYER7, PLAYER8, PLAYER9;

    @Override
    public String getKey() {
        return "" + (ordinal() + 1) + ". Player";
    }

    @Override
    public String getValue() {
        Player player = getPlayer();
        if (player == null) {
            return "/";
        }
        return String.valueOf(player.scores[TOTAL.ordinal()]);
    }

    @Override
    public boolean isHighlighted() {
        return ordinal() < 3;
    }

    @Override
    public boolean active() {
        return false;
    }

    @Override
    public boolean click(int xPos, int yPos, MouseButton button, Update update) {
        return false;
    }

    @Override
    public Color getColor() {
        Player player = getPlayer();
        if (player == null) {
            return FOREGROUND_COLOR;
        }
        return player.color;
    }

    private Player getPlayer() {
        if (ordinal() >= Player.rankedPlayer.size()) {
            return null;
        }
        return Player.rankedPlayer.get(this.ordinal());
    }
}
