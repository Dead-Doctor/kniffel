package kniffel.game;

import java.awt.Color;
import kniffel.dom.MouseButton;
import kniffel.dom.TableEntries;

/**
 * @author XD98742
 */
public enum Field implements TableEntries {
    // Upper Figures
    DICE1("Einer", false), DICE2("Zweier", false), DICE3("Dreier", false), DICE4("Vierer", false), DICE5("F�nfer", false),
    DICE6("Sechser", false),
    // Upper Totals
    UPPER_TOTAL("Summe oben", true), BONUS("Bonus", true), UPPER_TOTAL_BONUS("Gesamter oberer Teil", true),
    // Bottom Figures
    PASCH3("Dreierpasch", false), PASCH4("Viererpasch", false), FULLHOUSE("Full House", false),
    SMALL_STREET("Kleine Stra�e", false), BIG_STREET("Gro�e Stra�e", false), KNIFFEL("Kniffel", false), CHANCE("Chance", false),
    // Totals
    LOWER_TOTAL("Summe unten", true), UPPER_TOTAL_LOWER("Summe oben", true), TOTAL("Gesamtsumme", true);

    private String text;

    private boolean isStatistic;

    private Field(String text, boolean isStatistic) {
        this.text = text;
        this.isStatistic = isStatistic;
    }

    @Override
    public String getKey() {
        return text;
    }

    @Override
    public String getValue() {
        Player game = Player.get();
        if (!game.showValue[ordinal()]) {
            return "";
        }
        if (game.gestrichen[ordinal()]) {
            return "/";
        }
        return String.valueOf(game.scores[ordinal()]);
    }

    @Override
    public boolean isHighlighted() {
        return isStatistic;
    }

    @Override
    public boolean active() {
        return !Player.get().showValue[this.ordinal()];
    }

    @Override
    public boolean click(int xPos, int yPos, MouseButton button, Update updater) {
        Player.get()
              .select(this);
        updater.update();
        return true;
    }

    /**
     * @return the isStatistic
     */
    public boolean isStatistic() {
        return isStatistic;
    }

    @Override
    public Color getColor() {
        return Player.get().color;
    }
}
