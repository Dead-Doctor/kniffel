package kniffel.game;

import static kniffel.Constants.BACKGROUND_COLOR;
import static kniffel.Constants.DICE_SECTION_HEIGHT;
import static kniffel.Constants.PADDING;
import static kniffel.Constants.SCR_HEIGHT;
import static kniffel.Constants.SCR_MIN_HEIGHT;
import static kniffel.Constants.SCR_MIN_WIDTH;
import static kniffel.Constants.SCR_WIDTH;
import java.awt.Graphics;
import kniffel.dom.Table;
import kniffel.dom.Window;
import kniffel.game.dice.DicePanel;
import kniffel.game.dice.RollButton;

/**
 * @author XD98742
 */
public class BlockWindow extends Window {

    DicePanel dicePanel;

    RollButton rollButton;

    Table<Field> table;

    GameButton gameButton;

    public void init() {
        dicePanel = add(new DicePanel());
        rollButton = add(new RollButton());
        table = add(new Table<Field>(Field.class));
        gameButton = add(new GameButton());
        show("Player 1", SCR_WIDTH, SCR_HEIGHT, SCR_MIN_WIDTH, SCR_MIN_HEIGHT, BACKGROUND_COLOR);
    }

    @Override
    protected void onDraw(Graphics g) {
        int dicePanelYEnd = (int) (height() * DICE_SECTION_HEIGHT);
        dicePanel.offset(PADDING, PADDING);
        dicePanel.size(width() - PADDING * 2, dicePanelYEnd - PADDING * 2);

        int rollButtonYEnd = dicePanelYEnd + 30;
        rollButton.offset(PADDING, dicePanelYEnd);
        rollButton.size(width() - PADDING * 2, rollButtonYEnd - dicePanelYEnd - PADDING);

        int gameButtonHeight = 30;
        table.offset(PADDING, rollButtonYEnd);
        table.size(width() - PADDING * 2, height() - rollButtonYEnd - PADDING * 2 - gameButtonHeight);

        gameButton.offset(PADDING, height() - gameButtonHeight);
        gameButton.size(width() - PADDING * 2, gameButtonHeight - PADDING);
    }
}
