package kniffel.game;

import java.awt.Graphics;
import kniffel.dom.Button;
import kniffel.dom.MouseButton;

/**
 * @author XD98742
 */
public class GameButton extends Button {

    public GameButton() {
        show("Reset", true, false);
    }

    @Override
    protected void beforeDraw(Graphics g) {
        setText("End round");
    }

    @Override
    protected boolean onClick(int xPos, int yPos, MouseButton button) {
        Player.end();
        update();
        return true;
    }
}
