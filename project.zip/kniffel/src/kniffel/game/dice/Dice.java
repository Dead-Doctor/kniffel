package kniffel.game.dice;

import static kniffel.Constants.DICE_DOT_COLOR;
import static kniffel.Constants.DICE_FACES;
import static kniffel.Constants.FOREGROUND_COLOR;
import static kniffel.Constants.HOVER_COLOR;
import static kniffel.Constants.getLockedSymbol;
import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import kniffel.dom.Element;
import kniffel.dom.MouseButton;
import kniffel.game.Player;

/**
 * @author XD98742
 */
public class Dice extends Element {

    private int index;

    public Dice(int index) {
        this.index = index;
    }

    @Override
    protected boolean onClick(int xPos, int yPos, MouseButton button) {
        Player.get().lockedDice[index] = true;
        update();
        return true;
    }

    @Override
    protected void onDraw(Graphics g) {
        g.setColor(FOREGROUND_COLOR);
        g.fillRoundRect(0, 0, width(), height(), width() / 5, height() / 5);

        int dotSize = width() / 5;
        for (int[] dot : DICE_FACES[Player.get().dice[index]]) {
            g.setColor(DICE_DOT_COLOR);
            // @formatter:off
            g.fillOval(
                0 + width() / 2 + dot[0] * width() / 4 - dotSize / 2,
                0 + height() / 2 + dot[1] * height() / 4 - dotSize / 2,
                dotSize,
                dotSize
            );
            // @formatter:on
        }

        if (Player.get().lockedDice[index]) {
            int size = width() / 3;
            if (getLockedSymbol() != null) {
                g.drawImage(getLockedSymbol(), width() - size / 2, height() - size / 2, size, size, null);
            } else {
                g.setColor(HOVER_COLOR);
                g.drawArc(width() - size / 2, height() - size / 2, size, size, 0, 360);
            }
        }

        int hoverOffset = 5;
        if (isHovered()) {
            ((Graphics2D) g).setStroke(new BasicStroke(2f));
            g.setColor(HOVER_COLOR);
            g.drawRoundRect(-hoverOffset, -hoverOffset, width() + hoverOffset * 2, height() + hoverOffset * 2, width() / 5,
                height() / 5);
            ((Graphics2D) g).setStroke(new BasicStroke(1f));
        }
    }
}
