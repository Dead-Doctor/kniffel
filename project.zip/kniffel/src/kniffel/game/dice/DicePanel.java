package kniffel.game.dice;

import static kniffel.Constants.DARK_BACKGROUND_COLOR;
import java.awt.Graphics;
import kniffel.dom.Element;
import kniffel.game.Player;

/**
 * @author XD98742
 */
public class DicePanel extends Element {

    Dice[] dice = new Dice[5];

    public DicePanel() {
        Player game = Player.get();

        for (int i = 0; i < game.dice.length; i++) {
            dice[i] = add(new Dice(i));
        }
    }

    @Override
    protected void onDraw(Graphics g) {
        Player game = Player.get();

        g.setColor(DARK_BACKGROUND_COLOR);
        g.fillRect(0, 0, width(), height());

        int diceCount = game.dice.length;
        int dicePadding = Math.min(width() / 24, height() / 5);

        int diceSpace = (int) ((float) (width() - dicePadding) / diceCount) - dicePadding;
        int diceXStart = dicePadding;

        int diceSize = Math.min(diceSpace, height() - dicePadding * 2);

        int diceY = height() / 2 - diceSize / 2;

        for (int i = 0; i < diceCount; i++) {
            dice[i].offset(diceXStart + (diceSpace + dicePadding) * i, diceY);
            dice[i].size(diceSize);
        }
    }
}
