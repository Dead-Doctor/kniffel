package kniffel.game.dice;

import java.awt.Graphics;
import kniffel.dom.Button;
import kniffel.dom.MouseButton;
import kniffel.game.Player;

/**
 * @author XD98742
 */
public class RollButton extends Button {

    /**
     *
     */
    public RollButton() {
        show("Roll", true, false);
    }

    @Override
    protected void beforeDraw(Graphics g) {
        Player game = Player.get();
        setActive(game.rolls != 0);
    }

    @Override
    protected void afterDraw(Graphics g) {
        Player game = Player.get();
        int rollsIndicatorSize = height() / 3;

        for (int i = 0; i < game.rolls; i++) {
            g.fillOval(width() - (rollsIndicatorSize + 10) * (i + 1) - rollsIndicatorSize / 2,
                height() / 2 - rollsIndicatorSize / 2, rollsIndicatorSize, rollsIndicatorSize);
        }
    }

    @Override
    protected boolean onClick(int xPos, int yPos, MouseButton button) {
        Player.get()
             .roll();
        update();
        return true;
    }
}
