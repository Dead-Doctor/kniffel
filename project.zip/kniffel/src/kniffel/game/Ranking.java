package kniffel.game;

import static kniffel.Constants.BACKGROUND_COLOR;
import static kniffel.Constants.PADDING;
import java.awt.Graphics;
import kniffel.dom.Table;
import kniffel.dom.Window;

/**
 * @author XD98742
 */
public class Ranking extends Window {

    Table<PlayerScoreTable> playerScoreTable;

    public Ranking() {
        playerScoreTable = add(new Table<PlayerScoreTable>(PlayerScoreTable.class));
        show("Ranking", 500, 300, 300, 200, BACKGROUND_COLOR);
    }

    @Override
    protected void onDraw(Graphics g) {
        playerScoreTable.offset(PADDING, PADDING);
        playerScoreTable.size(width() - PADDING * 2, height() - PADDING * 2);
    }
}
