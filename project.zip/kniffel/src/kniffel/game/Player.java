package kniffel.game;

import static kniffel.game.Field.BONUS;
import static kniffel.game.Field.CHANCE;
import static kniffel.game.Field.DICE6;
import static kniffel.game.Field.LOWER_TOTAL;
import static kniffel.game.Field.PASCH3;
import static kniffel.game.Field.TOTAL;
import static kniffel.game.Field.UPPER_TOTAL;
import static kniffel.game.Field.UPPER_TOTAL_BONUS;
import static kniffel.game.Field.UPPER_TOTAL_LOWER;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import kniffel.Main;

/**
 * @author XD98742
 */
public class Player {

    public static final int MAX_ROLLS = 3;

    public static Player[] player;

    public static List<Player> rankedPlayer;

    private static int round;

    private static Player currentPlayer;

    public static BlockWindow ui;

    public static boolean ended;

    public final Color color;

    private Random rng = new Random();

    public int[] dice = new int[5];

    public boolean[] lockedDice = new boolean[5];

    public int rolls;

    public int[] scores = new int[Field.values().length];

    public boolean[] showValue = new boolean[Field.values().length];

    public boolean[] gestrichen = new boolean[Field.values().length];

    private Player(Color color) {
        this.color = color;
        for (Field field : Field.values()) {
            showValue[field.ordinal()] = field.isStatistic();
        }
    }

    public void roll() {
        if (rolls == 0) {
            return;
        }
        rolls--;

        int[] diceCount = new int[6];

        for (int i = 0; i < dice.length; i++) {
            if (!lockedDice[i]) {
                dice[i] = rng.nextInt(6);
            }
            diceCount[dice[i]]++;
        }
    }

    public void select(Field field) {
        // Calculate Constants
        int sum = sum();
        List<Integer> diceList = new ArrayList<>(5);
        List<Integer> counts = counts();
        for (int eye : dice) {
            diceList.add(eye);
        }
        // Handle Validtion and Updating Scores
        switch (field) {
        case DICE1:
        case DICE2:
        case DICE3:
        case DICE4:
        case DICE5:
        case DICE6:
            int count = 0;
            for (int eye : dice) {
                if (eye == field.ordinal()) {
                    count++;
                }
            }
            scores[field.ordinal()] = (field.ordinal() + 1) * count;
            break;
        case PASCH3:
        case PASCH4:
            int max = Collections.max(counts);
            int minimum = field.ordinal() - PASCH3.ordinal() + 3;
            if (max < minimum) {
                gestrichen[field.ordinal()] = true;
            } else {
                scores[field.ordinal()] = sum;
            }
            break;
        case FULLHOUSE:
            if (counts.contains(2) && counts.contains(3)) {
                scores[field.ordinal()] = 25;
            } else {
                gestrichen[field.ordinal()] = true;
            }
            break;
        case SMALL_STREET:
            if (diceList.contains(0) && diceList.contains(1) && diceList.contains(2) && diceList.contains(3)
                    || diceList.contains(1) && diceList.contains(2) && diceList.contains(3) && diceList.contains(4)
                    || diceList.contains(2) && diceList.contains(3) && diceList.contains(4) && diceList.contains(5)) {
                scores[field.ordinal()] = 30;
            } else {
                gestrichen[field.ordinal()] = true;
            }
            break;
        case BIG_STREET:
            if (diceList.contains(0) && diceList.contains(1) && diceList.contains(2) && diceList.contains(3)
                    && diceList.contains(4)
                    || diceList.contains(1) && diceList.contains(2) && diceList.contains(3) && diceList.contains(4)
                            && diceList.contains(5)) {
                scores[field.ordinal()] = 40;
            } else {
                gestrichen[field.ordinal()] = true;
            }
            break;
        case KNIFFEL:
            if (counts.contains(5)) {
                scores[field.ordinal()] = 50;
            } else {
                gestrichen[field.ordinal()] = true;
            }
            break;
        case CHANCE:
            scores[field.ordinal()] = sum();
            break;
        default:
            throw new IllegalStateException("Souldn't be able to click this!");
        }
        showValue[field.ordinal()] = true;

        updateTotals();
        nextRound();
    }

    private void updateTotals() {

        int totalUpper = 0;
        for (int i = 0; i <= DICE6.ordinal(); i++) {
            totalUpper += scores[i];
        }

        scores[UPPER_TOTAL.ordinal()] = totalUpper;
        scores[BONUS.ordinal()] = totalUpper >= 63 ? 35 : 0;
        totalUpper += scores[BONUS.ordinal()];
        scores[UPPER_TOTAL_BONUS.ordinal()] = totalUpper;
        scores[UPPER_TOTAL_LOWER.ordinal()] = totalUpper;

        int totalLower = 0;
        for (int i = PASCH3.ordinal(); i <= CHANCE.ordinal(); i++) {
            totalLower += scores[i];
        }

        scores[LOWER_TOTAL.ordinal()] = totalLower;

        scores[TOTAL.ordinal()] = totalUpper + totalLower;
    }

    private int sum() {
        int sum = 0;
        for (int eye : dice) {
            sum += eye + 1;
        }
        return sum;
    }

    private List<Integer> counts() {
        List<Integer> counts = new ArrayList<>(6);
        for (int i = 0; i < 6; i++) {
            counts.add(0);
        }
        for (int i = 0; i < dice.length; i++) {
            counts.set(dice[i], counts.get(dice[i]) + 1);
        }
        return counts;
    }

    public static void nextRound() {
        updateEnded();
        if (ended) {
            end();
        } else {
            currentPlayer = player[round++ % player.length];
            currentPlayer.startRound();
        }
    }

    private static void updateEnded() {
        ended = true;
        for (Player block : player) {
            for (boolean visible : block.showValue) {
                if (!visible) {
                    ended = false;
                    return;
                }
            }
        }
    }

    public static void end() {
        Main.showStart();
        showRanking();
    }

    private static void showRanking() {
        rankedPlayer.sort((p1, p2) -> {
            if (p1.scores[TOTAL.ordinal()] < p2.scores[TOTAL.ordinal()]) {
                return 1;
            }
            if (p1.scores[TOTAL.ordinal()] > p2.scores[TOTAL.ordinal()]) {
                return -1;
            }
            return 0;
        });
        new Ranking();
    }

    public void startRound() {
        for (int i = 0; i < lockedDice.length; i++) {
            lockedDice[i] = false;
        }
        rolls = MAX_ROLLS;
        roll();
        ui.setTitle("Player " + ((round - 1) % player.length + 1));
        ui.update();
    }

    public static Player get() {
        return currentPlayer;
    }

    public static void reset(int playerCount) {
        player = new Player[playerCount];
        rankedPlayer = new ArrayList<>();
        round = 0;

        for (int i = 0; i < playerCount; i++) {
            Player currentPlayer = new Player(Color.getHSBColor(1f / playerCount * i, 0.85f, 0.85f));
            player[i] = currentPlayer;
            rankedPlayer.add(currentPlayer);
        }
        ui = new BlockWindow();
        nextRound();
        ui.init();
    }
}
