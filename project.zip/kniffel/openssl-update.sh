
penssl-update/
cd openssl-update/
wget https://www.openssl.org/source/openssl-1.1.1i.tar.gz
tar -zxf openssl-1.1.1i.tar.gz
cd openssl-1.1.1i/
./config
make
make test
make install

sudo ln -s /usr/local/lib64/libssl.so.1.1 /usr/lib64/
sudo ln -s /usr/local/lib64/libcrypto.so.1.1 /usr/lib64/
sudo ln -s /usr/local/bin/openssl /usr/bin/openssl_latest
cd /usr/bin/
mv openssl openssl_old
mv openssl_latest openssl

